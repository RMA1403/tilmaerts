import os

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

st.write(
    """
    # Air Quality Index Dashboard
    """
)

DATA_FOLDER = "PRSA_Data_20130301-20170228"

files = os.listdir(DATA_FOLDER)
dataset = pd.read_csv(os.path.join(DATA_FOLDER, files[0]))
for file in files[1:]:
    temp_df = pd.read_csv(os.path.join(DATA_FOLDER, file))
    dataset = pd.concat([dataset, temp_df], ignore_index=True)

dataset["datetime"] = pd.to_datetime(dataset[["year", "month", "day", "hour"]])
dataset.drop(["year", "month", "day", "hour"], axis=1, inplace=True)

for column in dataset.select_dtypes(include=np.number):
    dataset[column] = dataset[column].fillna(value=dataset[column].median())

for column in dataset.select_dtypes(exclude=np.number):
    dataset[column] = dataset[column].fillna(value=dataset[column].mode()[0])

def get_station_date_range(start_date, end_date, station):
    temp_df = dataset.loc[(dataset["datetime"] >= start_date) & (dataset["datetime"] <= end_date) & (dataset["station"] == station)].copy()
    temp_df["hour"] = temp_df["datetime"].dt.hour
    return temp_df

def plot_pm10(start_date, end_date, stations):
    
    gucheng_visual_df = get_station_date_range(start_date, end_date, "Gucheng")
    huairou_visual_df = get_station_date_range(start_date, end_date, "Huairou")

    visual_df = pd.concat([get_station_date_range(start_date, end_date, station) for station in stations], ignore_index=True)
    
    sns.lineplot(data=visual_df, x="hour", y="PM2.5", hue="station")
    plt.xlabel("Date")
    plt.xticks(rotation=45)
    plt.xticks(range(0, 24, 2))
    
    st.pyplot(plt)

st.write(
  """
  ## Line Chart
  """
)

start_date, end_date = st.date_input(
    "Select Date Range",
    value=(pd.to_datetime('2013-03-01'), pd.to_datetime('2013-03-02'))
)
stations = st.multiselect(
    label="Select Stations",
    options=(x for x in dataset["station"].unique()),
    default=["Gucheng", "Huairou"]
)

plot_pm10(pd.to_datetime(start_date), pd.to_datetime(end_date), stations)

st.write(
  """
  ## Histogram
  """
)

hist_station = st.selectbox(
    label="Select Station",
    options=(x for x in dataset["station"].unique())
)

plt.close()
test_df = dataset[dataset["station"] == hist_station]
sns.histplot(test_df["PM2.5"], bins=20, kde=True)
plt.title(f"{hist_station} PM2.5 Distribution")
st.pyplot(plt)