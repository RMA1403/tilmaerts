# Proyek Analisis Data: Air Quality Index (PM2.5)
- **Nama:** Rava Maulana
- **Email:** ravamaulana14@gmail.com
- **ID Dicoding:** rma1403

## Run steamlit app
```
pip install -r requirements.txt
streamlit run streamlit.py
```